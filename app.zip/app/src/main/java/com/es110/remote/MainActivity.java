package com.es110.remote;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.midi.MidiDevice;
import android.media.midi.MidiDeviceInfo;
import android.media.midi.MidiInputPort;
import android.media.midi.MidiManager;
import android.media.midi.MidiOutputPort;
import android.media.midi.MidiReceiver;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Hosts the ES110 Remote page in a WebView and gives it MIDI access through
 * Android's own MIDI service (Android WebView has no Web MIDI support).
 * The page sees a navigator.requestMIDIAccess() provided by a small shim in index.html.
 */
public class MainActivity extends Activity {

    private static final UUID BLE_MIDI_SERVICE = UUID.fromString("03B80E5A-EDE8-4B33-A751-6CE34EC4C700");
    private static final int REQ_PERMS = 1;
    private static final long SCAN_TIMEOUT_MS = 12000;

    private WebView web;
    private MidiManager midi;
    private final Handler main = new Handler(Looper.getMainLooper());

    // Opened devices, keyed by MidiDeviceInfo id
    private final Map<Integer, MidiDevice> devices = new HashMap<>();
    private final Map<Integer, String> deviceNames = new HashMap<>();
    private final Map<Integer, String> deviceBleAddress = new HashMap<>();
    private final Set<Integer> pendingOpen = new HashSet<>();

    // Ports, keyed by the id the page sees ("o-<dev>-<port>" / "i-<dev>-<port>")
    private final Map<String, MidiInputPort> sendPorts = new ConcurrentHashMap<>();
    private final Map<String, MidiOutputPort> listenPorts = new ConcurrentHashMap<>();
    private final Map<String, String> portNames = new ConcurrentHashMap<>();

    // Bluetooth scanning
    private final Set<String> bleOpened = new HashSet<>();
    private BluetoothLeScanner scanner;
    private ScanCallback scanCallback;
    private boolean scanning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(0xFF14161A);
        getWindow().setNavigationBarColor(0xFF14161A);

        web = new WebView(this);
        web.setBackgroundColor(0xFF14161A);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidMidi");
        setContentView(web);

        if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_MIDI)) {
            midi = (MidiManager) getSystemService(Context.MIDI_SERVICE);
        }
        if (midi != null) {
            midi.registerDeviceCallback(new MidiManager.DeviceCallback() {
                @Override
                public void onDeviceAdded(MidiDeviceInfo info) {
                    // Bluetooth devices are opened through openBluetoothDevice() below.
                    if (info.getType() != MidiDeviceInfo.TYPE_BLUETOOTH) openInfo(info);
                }

                @Override
                public void onDeviceRemoved(MidiDeviceInfo info) {
                    closeDevice(info.getId(), true);
                }
            }, main);
            for (MidiDeviceInfo info : midi.getDevices()) {
                if (info.getType() != MidiDeviceInfo.TYPE_BLUETOOTH) openInfo(info);
            }
        }

        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onDestroy() {
        stopScan();
        for (Integer id : new ArrayList<>(devices.keySet())) closeDevice(id, false);
        if (web != null) web.destroy();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ JS bridge

    public class Bridge {
        @JavascriptInterface
        public String ports() {
            return portsJson();
        }

        @JavascriptInterface
        public void start() {
            main.post(MainActivity.this::startBluetooth);
        }

        @JavascriptInterface
        public void send(String portId, String csv) {
            MidiInputPort port = sendPorts.get(portId);
            if (port == null || csv == null || csv.isEmpty()) return;
            String[] parts = csv.split(",");
            byte[] bytes = new byte[parts.length];
            try {
                for (int i = 0; i < parts.length; i++) {
                    bytes[i] = (byte) Integer.parseInt(parts[i].trim());
                }
                port.send(bytes, 0, bytes.length);
            } catch (NumberFormatException | IOException ignored) {
            }
        }
    }

    private void js(final String code) {
        main.post(() -> {
            if (web != null) web.evaluateJavascript(code, null);
        });
    }

    private void status(String text) {
        js("window.__midiStatus&&window.__midiStatus(" + JSONObject.quote(text) + ")");
    }

    private void notifyState() {
        js("window.__midiState&&window.__midiState(" + portsJson() + ")");
    }

    private String portsJson() {
        JSONObject root = new JSONObject();
        JSONArray outs = new JSONArray();
        JSONArray ins = new JSONArray();
        try {
            for (String id : sendPorts.keySet()) {
                outs.put(new JSONObject().put("id", id).put("name", portNames.get(id)));
            }
            for (String id : listenPorts.keySet()) {
                ins.put(new JSONObject().put("id", id).put("name", portNames.get(id)));
            }
            root.put("outputs", outs).put("inputs", ins);
        } catch (JSONException ignored) {
        }
        return root.toString();
    }

    // ------------------------------------------------------------------ MIDI devices

    private static String nameOf(MidiDeviceInfo info) {
        Bundle p = info.getProperties();
        String n = p.getString(MidiDeviceInfo.PROPERTY_NAME);
        if (n == null) n = p.getString(MidiDeviceInfo.PROPERTY_PRODUCT);
        return n != null ? n : "MIDI device";
    }

    private void openInfo(final MidiDeviceInfo info) {
        final int id = info.getId();
        if (devices.containsKey(id) || pendingOpen.contains(id)) return;
        pendingOpen.add(id);
        midi.openDevice(info, device -> {
            pendingOpen.remove(id);
            if (device != null) addDevice(device, nameOf(info), null);
        }, main);
    }

    private void addDevice(MidiDevice device, String name, String bleAddress) {
        MidiDeviceInfo info = device.getInfo();
        int id = info.getId();
        if (devices.containsKey(id)) {
            try { device.close(); } catch (IOException ignored) { }
            return;
        }
        devices.put(id, device);
        deviceNames.put(id, name);
        if (bleAddress != null) deviceBleAddress.put(id, bleAddress);

        for (MidiDeviceInfo.PortInfo p : info.getPorts()) {
            int n = p.getPortNumber();
            if (p.getType() == MidiDeviceInfo.PortInfo.TYPE_INPUT) {
                // The device's input = where we send = a Web MIDI "output"
                MidiInputPort in = device.openInputPort(n);
                if (in != null) {
                    String pid = "o-" + id + "-" + n;
                    sendPorts.put(pid, in);
                    portNames.put(pid, name);
                }
            } else {
                MidiOutputPort out = device.openOutputPort(n);
                if (out != null) {
                    String pid = "i-" + id + "-" + n;
                    listenPorts.put(pid, out);
                    portNames.put(pid, name);
                    out.connect(new Forwarder(pid));
                }
            }
        }
        notifyState();
        status("Connected to " + name);
    }

    private void closeDevice(int id, boolean announce) {
        String prefixO = "o-" + id + "-";
        String prefixI = "i-" + id + "-";
        for (String k : new ArrayList<>(sendPorts.keySet())) {
            if (k.startsWith(prefixO)) {
                try { sendPorts.remove(k).close(); } catch (IOException ignored) { }
                portNames.remove(k);
            }
        }
        for (String k : new ArrayList<>(listenPorts.keySet())) {
            if (k.startsWith(prefixI)) {
                try { listenPorts.remove(k).close(); } catch (IOException ignored) { }
                portNames.remove(k);
            }
        }
        MidiDevice d = devices.remove(id);
        String name = deviceNames.remove(id);
        String addr = deviceBleAddress.remove(id);
        if (addr != null) bleOpened.remove(addr);
        if (d != null) {
            try { d.close(); } catch (IOException ignored) { }
            if (announce) {
                notifyState();
                status((name != null ? name : "MIDI device") + " disconnected. Tap Refresh to reconnect.");
            }
        }
    }

    /** Splits incoming bytes into complete MIDI messages and hands them to the page. */
    private class Forwarder extends MidiReceiver {
        private final String pid;
        private int running = 0;
        private boolean inSysex = false;

        Forwarder(String pid) { this.pid = pid; }

        @Override
        public void onSend(byte[] data, int offset, int count, long timestamp) {
            int i = offset, end = offset + count;
            while (i < end) {
                int b = data[i] & 0xFF;
                if (inSysex) { if (b == 0xF7) inSysex = false; i++; continue; }
                if (b >= 0xF8) { i++; continue; }                 // real-time
                if (b == 0xF0) { inSysex = true; i++; continue; } // sysex start
                if (b >= 0xF0) { running = 0; i++; continue; }    // other system common
                if (b >= 0x80) { running = b; i++; }
                else if (running == 0) { i++; continue; }         // stray data byte
                int type = running & 0xF0;
                int need = (type == 0xC0 || type == 0xD0) ? 1 : 2;
                if (i + need > end) break;
                StringBuilder sb = new StringBuilder();
                sb.append(running);
                for (int k = 0; k < need; k++) sb.append(',').append(data[i + k] & 0x7F);
                i += need;
                js("window.__midiIn&&window.__midiIn('" + pid + "',[" + sb + "])");
            }
        }
    }

    // ------------------------------------------------------------------ Bluetooth

    private String[] neededPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT};
        }
        return new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
    }

    private void startBluetooth() {
        if (midi == null) {
            status("This phone doesn't support MIDI.");
            return;
        }
        List<String> missing = new ArrayList<>();
        for (String p : neededPermissions()) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        }
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQ_PERMS);
            return;
        }
        BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = bm != null ? bm.getAdapter() : null;
        if (adapter == null) {
            status("This phone has no Bluetooth.");
            return;
        }
        if (!adapter.isEnabled()) {
            status("Turn Bluetooth on, then tap Refresh.");
            try {
                startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
            } catch (Exception ignored) {
            }
            return;
        }
        if (!bleOpened.isEmpty()) {   // already connected to the piano
            notifyState();
            return;
        }
        if (scanning) return;
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            status("Bluetooth isn't ready yet. Tap Refresh in a moment.");
            return;
        }
        scanCallback = new ScanCallback() {
            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                handleScanResult(result);
            }

            @Override
            public void onBatchScanResults(List<ScanResult> results) {
                for (ScanResult r : results) handleScanResult(r);
            }

            @Override
            public void onScanFailed(int errorCode) {
                scanning = false;
                status("Bluetooth search failed (code " + errorCode + "). Tap Refresh to try again.");
            }
        };
        ScanSettings settings = new ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build();
        try {
            scanner.startScan(null, settings, scanCallback);
        } catch (SecurityException e) {
            status("Bluetooth permission is needed. Tap Refresh to allow it.");
            return;
        }
        scanning = true;
        status("Searching for the piano… make sure it's switched on.");
        main.postDelayed(() -> {
            if (scanning) {
                stopScan();
                String extra = Build.VERSION.SDK_INT < 31 ? " On this Android version, Location must also be switched on." : "";
                status("Piano not found. Check it's on and not connected to another device (like your Mac), then tap Refresh." + extra);
            }
        }, SCAN_TIMEOUT_MS);
    }

    private void handleScanResult(ScanResult r) {
        if (!scanning || r == null) return;
        BluetoothDevice dev = r.getDevice();
        ScanRecord rec = r.getScanRecord();
        String name = rec != null ? rec.getDeviceName() : null;
        boolean isMidi = false;
        if (rec != null && rec.getServiceUuids() != null) {
            for (ParcelUuid u : rec.getServiceUuids()) {
                if (BLE_MIDI_SERVICE.equals(u.getUuid())) { isMidi = true; break; }
            }
        }
        String upper = name != null ? name.toUpperCase(Locale.ROOT) : "";
        boolean looksKawai = upper.contains("ES110") || upper.contains("ES-110") || upper.contains("KAWAI");
        if (!isMidi && !looksKawai) return;

        final String addr = dev.getAddress();
        if (bleOpened.contains(addr)) return;
        bleOpened.add(addr);
        stopScan();

        final String label = name != null && !name.isEmpty() ? name : "Bluetooth MIDI";
        status("Connecting to " + label + "…");
        midi.openBluetoothDevice(dev, device -> {
            if (device == null) {
                bleOpened.remove(addr);
                status("Couldn't connect to " + label + ". Tap Refresh to try again.");
            } else {
                addDevice(device, label, addr);
            }
        }, main);
    }

    private void stopScan() {
        if (scanning && scanner != null && scanCallback != null) {
            try {
                scanner.stopScan(scanCallback);
            } catch (Exception ignored) {
            }
        }
        scanning = false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMS) return;
        boolean all = grantResults.length > 0;
        for (int g : grantResults) if (g != PackageManager.PERMISSION_GRANTED) all = false;
        if (all) {
            startBluetooth();
        } else {
            status("Bluetooth permission was refused. Allow “Nearby devices” for ES110 Remote in your phone's Settings → Apps, then tap Refresh.");
        }
    }
}
